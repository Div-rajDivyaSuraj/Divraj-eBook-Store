import React, { useMemo, useState, useEffect } from "react"

const BOOKS = [
  { id:"b1", title:"Mastering Modern JavaScript", author:"A. Gupta", price:7.99, rating:4.7, reviews:312, genre:"Programming", emoji:"📘", blurb:"A fast, practical guide to ES2023+ essentials, patterns, and performance techniques for web devs." },
  { id:"b2", title:"The Minimalist Entrepreneur", author:"K. Rao", price:5.49, rating:4.5, reviews:201, genre:"Business", emoji:"💼", blurb:"Build a calm, profitable online business with focus, tiny bets, and tight feedback loops." },
  { id:"b3", title:"Atomic Writing Habits", author:"S. Iyer", price:4.99, rating:4.8, reviews:518, genre:"Productivity", emoji:"✍️", blurb:"Tiny routines that help you publish consistently without burning out." },
  { id:"b4", title:"Data Science Sprint", author:"R. Sharma", price:8.99, rating:4.6, reviews:144, genre:"Data", emoji:"📊", blurb:"Hands‑on projects that take you from pandas to production in a week." },
  { id:"b5", title:"Design for Brains", author:"M. Kapoor", price:6.49, rating:4.4, reviews:98, genre:"Design", emoji:"🎨", blurb:"UX psychology principles that actually move metrics." },
  { id:"b6", title:"TypeScript in Action", author:"N. Verma", price:7.49, rating:4.7, reviews:265, genre:"Programming", emoji:"💻", blurb:"From types to tooling—build safer front‑ends without slowing down." },
]

const GENRES = ["All", ...Array.from(new Set(BOOKS.map(b=>b.genre)))]

const currency = (n)=> `₹${n.toFixed(2)}`
const load = (k, v=null)=>{ try { return JSON.parse(localStorage.getItem(k)) ?? v } catch { return v } }
const save = (k, v)=> localStorage.setItem(k, JSON.stringify(v))

export default function App(){
  const [query, setQuery] = useState("")
  const [genre, setGenre] = useState("All")
  const [maxPrice, setMaxPrice] = useState(10)
  const [sort, setSort] = useState("relevance")
  const [cartOpen, setCartOpen] = useState(false)
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [cart, setCart] = useState(()=> load("divraj_cart", {}))
  const [toast, setToast] = useState("")

  useEffect(()=> save("divraj_cart", cart), [cart])
  useEffect(()=> { if(toast){ const t=setTimeout(()=>setToast(""), 1500); return ()=>clearTimeout(t) }}, [toast])

  const filtered = useMemo(()=>{
    let list = BOOKS.filter(b=>
      (genre==="All" || b.genre===genre) &&
      b.price <= maxPrice &&
      (b.title + b.author).toLowerCase().includes(query.toLowerCase())
    )
    if (sort==="price-asc") list.sort((a,b)=>a.price-b.price)
    if (sort==="price-desc") list.sort((a,b)=>b.price-a.price)
    if (sort==="rating") list.sort((a,b)=>b.rating-a.rating)
    return list
  }, [query, genre, maxPrice, sort])

  const items = Object.entries(cart).map(([id, qty]) => ({...BOOKS.find(b=>b.id===id), qty}))
  const subtotal = items.reduce((s,i)=> s + i.price*i.qty, 0)

  function add(id){ setCart(c=> ({...c, [id]:(c[id]||0)+1})); setToast("Added to cart") }
  function dec(id){ setCart(c=>{ const n={...c}; if(!n[id]) return n; if(n[id]===1) delete n[id]; else n[id]-=1; return n }) }
  function removeItem(id){ setCart(c=>{ const n={...c}; delete n[id]; return n }) }
  function clear(){ setCart({}) }

  return (
    <div className="min-h-screen text-slate-800">
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-indigo-600 text-white grid place-items-center">📚</div>
            <div className="font-bold">Divraj eBook Store</div>
          </div>
          <div className="flex items-center gap-2">
            <a className="text-sm hover:underline" href="#catalog">Catalog</a>
            <a className="text-sm hover:underline" href="#about">About</a>
            <button className="relative px-3 py-2 rounded-lg bg-indigo-600 text-white"
              onClick={()=>setCartOpen(true)}>
              Cart
              <span className="ml-2 px-2 py-0.5 text-xs bg-white/20 rounded-full">{Object.values(cart).reduce((a,b)=>a+b,0)}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <section className="rounded-2xl border bg-gradient-to-r from-indigo-50 to-white p-6 mb-6">
          <h1 className="text-2xl md:text-3xl font-bold">Discover ebooks you’ll actually finish</h1>
          <p className="text-slate-600 mt-1">Curated, affordable PDFs & EPUBs. Instant downloads.</p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <a href="#catalog"><button className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Browse Catalog</button></a>
            <div className="flex items-center gap-2 text-sm">
              Popular:
              {GENRES.filter(g=>g!=="All").map(g=>(
                <span key={g} className="px-2 py-1 border rounded-full text-slate-600">{g}</span>
              ))}
            </div>
          </div>
        </section>

        <section className="grid md:grid-cols-12 gap-4">
          <aside className="md:col-span-3 order-last md:order-first">
            <div className="border rounded-xl p-4 sticky top-20">
              <div className="font-semibold mb-2">Filters</div>
              <label className="block text-xs uppercase text-slate-500">Genre</label>
              <select value={genre} onChange={e=>setGenre(e.target.value)} className="w-full border rounded-lg p-2 mt-1">
                {GENRES.map(g=> <option key={g} value={g}>{g}</option>)}
              </select>
              <div className="mt-4">
                <label className="block text-xs uppercase text-slate-500">Max Price</label>
                <input type="range" min="0" max="10" step="0.5" value={maxPrice} onChange={e=>setMaxPrice(parseFloat(e.target.value))} className="w-full mt-2"/>
                <div className="text-sm text-slate-600 mt-1">Up to <span className="font-semibold">{currency(maxPrice)}</span></div>
              </div>
              <div className="mt-4">
                <label className="block text-xs uppercase text-slate-500">Sort by</label>
                <select value={sort} onChange={e=>setSort(e.target.value)} className="w-full border rounded-lg p-2 mt-1">
                  <option value="relevance">Relevance</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
              </div>
            </div>
          </aside>

          <section id="catalog" className="md:col-span-9">
            <div className="flex items-center gap-2 mb-3">
              <div className="relative flex-1">
                <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search title or author" className="w-full border rounded-lg pl-3 pr-3 py-2"/>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filtered.map(b => (
                <div key={b.id} className="border rounded-2xl overflow-hidden bg-white shadow-sm">
                  <div className="h-40 grid place-items-center text-6xl bg-gradient-to-br from-indigo-500/10 to-indigo-500/0">{b.emoji}</div>
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="font-semibold leading-tight">{b.title}</div>
                        <div className="text-sm text-slate-500">By {b.author}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{currency(b.price)}</div>
                        <div className="text-xs text-slate-500">⭐ {b.rating} · {b.reviews}</div>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 mt-2 line-clamp-3">{b.blurb}</p>
                    <div className="flex gap-2 mt-3">
                      <button className="flex-1 px-3 py-2 rounded-lg bg-indigo-600 text-white" onClick={()=>add(b.id)}>Add to cart</button>
                      <button className="px-3 py-2 rounded-lg border">Sample</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </section>
      </main>

      {/* Cart Drawer */}
      {cartOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setCartOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-xl p-4 overflow-auto">
            <div className="flex items-center justify-between">
              <div className="text-lg font-semibold">Your Cart</div>
              <button className="text-slate-600" onClick={()=>setCartOpen(false)}>✕</button>
            </div>
            <p className="text-sm text-slate-500">Secure checkout. Instant downloads.</p>
            <div className="mt-3 space-y-3">
              {items.length===0 && <p className="text-sm text-slate-500">Your cart is empty.</p>}
              {items.map(it => (
                <div key={it.id} className="border rounded-xl p-3 flex gap-3 items-center">
                  <div className="h-14 w-12 grid place-items-center bg-indigo-600 text-white rounded-md text-2xl">{it.emoji}</div>
                  <div className="flex-1">
                    <div className="text-sm font-medium leading-tight">{it.title}</div>
                    <div className="text-xs text-slate-500">{it.author}</div>
                    <div className="text-sm mt-0.5">{currency(it.price)}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="w-7 h-7 border rounded" onClick={()=>dec(it.id)}>-</button>
                    <div className="w-6 text-center text-sm">{it.qty}</div>
                    <button className="w-7 h-7 border rounded" onClick={()=>add(it.id)}>+</button>
                  </div>
                  <button className="ml-2 text-slate-500" onClick={()=>removeItem(it.id)}>🗑️</button>
                </div>
              ))}
            </div>
            <div className="my-4 border-t"></div>
            <div className="flex items-center justify-between text-sm">
              <span>Subtotal</span>
              <span className="font-semibold">{currency(subtotal)}</span>
            </div>
            <button disabled={!items.length} onClick={()=>{ setCheckoutOpen(true); setCartOpen(false) }} className={"w-full mt-3 px-4 py-2 rounded-lg text-white " + (items.length ? "bg-indigo-600" : "bg-indigo-300 cursor-not-allowed")}>Proceed to Checkout</button>
            {items.length>0 && <button onClick={clear} className="w-full mt-2 px-4 py-2 rounded-lg border">Clear cart</button>}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setCheckoutOpen(false)} />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-3xl bg-white rounded-2xl shadow-xl p-6">
            <div className="text-xl font-semibold">Checkout</div>
            <p className="text-sm text-slate-500">Enter your email to receive download links instantly.</p>
            <div className="grid md:grid-cols-2 gap-6 mt-4">
              <div>
                <div className="font-medium mb-2">Order Summary</div>
                <div className="space-y-3 max-h-64 overflow-auto pr-1">
                  {items.length===0 ? (
                    <p className="text-sm text-slate-500">No items. Add ebooks to continue.</p>
                  ) : items.map(it => (
                    <div key={it.id} className="flex items-center gap-3">
                      <div className="h-14 w-12 grid place-items-center bg-indigo-600 text-white rounded-md text-2xl">{it.emoji}</div>
                      <div className="flex-1">
                        <div className="text-sm font-medium leading-tight">{it.title}</div>
                        <div className="text-xs text-slate-500">Qty {it.qty}</div>
                      </div>
                      <div className="text-sm">{currency(it.price * it.qty)}</div>
                    </div>
                  ))}
                </div>
                <div className="my-3 border-t"></div>
                <div className="flex items-center justify-between text-sm">
                  <span>Subtotal</span>
                  <span className="font-semibold">{currency(subtotal)}</span>
                </div>
              </div>
              <form onSubmit={(e)=>{ e.preventDefault(); clear(); setCheckoutOpen(false); alert('Payment simulated – download links unlocked.'); }} className="space-y-3">
                <div>
                  <label className="block text-sm font-medium">Full name</label>
                  <input required placeholder="Your name" className="w-full border rounded-lg p-2 mt-1"/>
                </div>
                <div>
                  <label className="block text-sm font-medium">Email address</label>
                  <input required type="email" placeholder="you@example.com" className="w-full border rounded-lg p-2 mt-1"/>
                </div>
                <div>
                  <label className="block text-sm font-medium">Card number</label>
                  <input required inputMode="numeric" pattern="[0-9 ]{12,19}" placeholder="4242 4242 4242 4242" className="w-full border rounded-lg p-2 mt-1"/>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium">Expiry</label>
                    <input required placeholder="MM/YY" className="w-full border rounded-lg p-2 mt-1"/>
                  </div>
                  <div>
                    <label className="block text-sm font-medium">CVC</label>
                    <input required placeholder="123" className="w-full border rounded-lg p-2 mt-1"/>
                  </div>
                </div>
                <button className={"w-full px-4 py-2 rounded-lg text-white " + (items.length ? "bg-indigo-600" : "bg-indigo-300 cursor-not-allowed")} disabled={!items.length} type="submit">
                  Pay {currency(subtotal)}
                </button>
                <p className="text-xs text-slate-500">This is a demo checkout. Replace with Stripe or Razorpay in production.</p>
              </form>
            </div>
          </div>
        </div>
      )}

      <footer id="about" className="mt-16 border-t">
        <div className="max-w-6xl mx-auto px-4 py-10 grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="font-semibold mb-1">Divraj eBook Store</div>
            <p className="text-slate-600">Digital bookstore. © {new Date().getFullYear()}</p>
          </div>
          <div>
            <div className="font-semibold mb-1">Help</div>
            <ul className="space-y-1 text-slate-600">
              <li>Refund policy</li>
              <li>Terms of service</li>
              <li>Privacy policy</li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-1">Newsletter</div>
            <div className="flex gap-2">
              <input placeholder="you@example.com" className="flex-1 border rounded-lg p-2"/>
              <button className="px-3 py-2 rounded-lg border">Subscribe</button>
            </div>
          </div>
        </div>
      </footer>

      {toast && <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-black text-white text-sm px-3 py-2 rounded">{toast}</div>}
    </div>
  )
}
