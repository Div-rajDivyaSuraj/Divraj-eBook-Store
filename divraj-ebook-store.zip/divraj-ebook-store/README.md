# Divraj eBook Store

A minimal, production-ready eBook store built with **Vite + React + Tailwind**.

## Local Development
```bash
npm install
npm run dev
```
Visit http://localhost:5173

## Build
```bash
npm run build
npm run preview
```

## Deploy to Vercel
- Import this repo on Vercel
- Framework preset: **Vite**
- Build command: `npm run build`
- Output directory: `dist/`
